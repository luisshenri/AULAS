sequencia = [0,1,2,3,4,5]


for i in sequencia:
    print(i)
