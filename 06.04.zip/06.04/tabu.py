n1 = int(input('Digite um númeo para mostrar a sua tabuada: '))

print(' %i x 1 = %i' %(n1, (n1*1))) 
print(' %i x 2 = %i' %(n1, (n1*2)))
print(' %i x 3 = %i' %(n1, (n1*3))) 
print(' %i x 4 = %i' %(n1, (n1*4))) 
print(' %i x 6 = %i' %(n1, (n1*5))) 
print(' %i x 7 = %i' %(n1, (n1*6))) 
print(' %i x 8 = %i' %(n1, (n1*7))) 
print(' %i x 9 = %i' %(n1, (n1*8))) 
print(' %i x 10 = %i' %(n1, (n1*9))) 
print(' %i x 1 = %i' %(n1, (n1*10))) 


    
    















