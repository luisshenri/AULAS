from random import *

num = randint(0, 100)
i = 0
controle = 0
while controle == 0:
    i = i+1
    palpite = int(input('Digite um número inteiro: '))
    if palpite == num:
        print(f"Parabéns você acertou em {i} tentativas") 
        controle=1
    elif palpite > num:
        print("O numero digitado é maior que o numero sorteado")
    else:
        print("O numero digitado é menor que o numero sorteado")        
