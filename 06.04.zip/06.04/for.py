animais = ['gato', 'cachorro', 'camelo', 'leão']

for a in animais:
    print('A palavra ', a, 'tem um tamanho: ', len(a))