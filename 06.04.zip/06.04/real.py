soma= 0

for i in range(10):
    num = float(input('Digite um número: '))
    soma = soma + num
    
print('O resultado da soma é: ', soma)    