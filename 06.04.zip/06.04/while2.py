
qtdenota = 0
soma = 0
resp = 's'

while resp == 's' or resp =='S':
    num = float(input('Digite uma nota'))
    soma = soma+num
    qtdenota = qtdenota + 1
    resp = input('Deseja continuar (S/N): ')
    
    
media = soma / qtdenota
print('A media das notas digitadas é %.2f' %media)    


