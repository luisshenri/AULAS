nome = 'luis'

for letra in nome:
    print(letra, end="")