n1 = int(input('Digite um numero para tabuada: '))

for tabuada in range(10) :
    print('%d x %d = %d' %(n1, tabuada, (n1*tabuada)))